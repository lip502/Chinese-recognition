function varargout = Classification(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Classification_OpeningFcn, ...
                   'gui_OutputFcn',  @Classification_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Classification is made visible.
function Classification_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
msgbox('Q115195686')
%--------------------------------------------------------------------------
global flag
flag=0;

if exist('template.mat','file')~=0
    load template pattern;
else
    pattern(1,1).num=0;
    pattern(1,1).feature=[];

    pattern(1,2).num=0;
    pattern(1,2).feature=[];

    pattern(1,3).num=0;
    pattern(1,3).feature=[];

    pattern(1,4).num=0;
    pattern(1,4).feature=[];

    pattern(1,5).num=0;
    pattern(1,5).feature=[];

    pattern(1,6).num=0;
    pattern(1,6).feature=[];

    pattern(1,7).num=0;
    pattern(1,7).feature=[];

    pattern(1,8).num=0;
    pattern(1,8).feature=[];

    pattern(1,9).num=0;
    pattern(1,9).feature=[];

    pattern(1,10).num=0;
    pattern(1,10).feature=[];
    save template pattern;
end
%------------------------------------------------------------------------

% --- Outputs from this function are returned to the command line.
function varargout = Classification_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;


%--------------------------------------------------------------------------
%��д��ʵ��---���������ʼ��ֱ��
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
global flag
global pos0  %
global x0 y0

pos0=get(handles.WritingAxes,'currentpoint');
x0=pos0(1,1);
y0=pos0(1,2);
if (pos0(1,1)>=0&pos0(1,1)<=100) && (pos0(1,2)>=0&pos0(1,2)<=100)  
    flag=1;
end
%--------------------------------------------------------------------------



%--------------------------------------------------------------------------
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
%clc
%��д��ʵ��---�ƶ������л���ʵ�ֵĳ���

global flag
global pos0
global x0 y0

 pos=get(handles.WritingAxes,'currentpoint');   
 x=pos(1,1);
 y=pos(1,2);
 if flag && (pos(1,1)>=0&pos(1,1)<100) && (pos(1,2)>=0&pos(1,2)<100)  
      line(x,y, 'marker', '.','markerSize',18, 'LineStyle','-','LineWidth',2,'Color','Black');
      if x>x0
          stepX=0.1;
      else
          stepX=-0.1;
      end
      if y>y0
          stepY=0.1;
      else
          stepY=-0.1;
      end
      X=x0:stepX:x;      
                          
      if abs(x-x0)<0.01    
          Y=y0:stepY:y;     
      else
         Y=(y-y0)*(X-x0)/(x-x0)+y0;   
      end
      line(X ,Y, 'marker', '.','markerSize',18, 'LineStyle','-','LineWidth',2,'Color','Black');
      x0=x;
      y0=y;
      pos0=pos;
 else
      flag=0;
 end
 %-------------------------------------------------------------------------
 
 

 %-------------------------------------------------------------------------
function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
%clc
%��д��ʵ�ֳ���---�ͷ��������������ߵĳ���
global flag
flag=0;

%global data



%data=GetFeature(I);
%--------------------------------------------------------------------------





% --- Executes on selection change in popupmenuNUM.
function popupmenuNUM_Callback(hObject, eventdata, handles)
%-------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function popupmenuNUM_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
%-------------------------------------------------------------------------

%-------------------------------------------------------------------------
function pushbuttonSave_Callback(hObject, eventdata, handles)
load template pattern;        
save template pattern;       
%--------------------------------------------------------------------------


%-------------------------------------------------------------------------
function pushbuttonFeature_Callback(hObject, eventdata, handles)


%-------------------------------------------------------------------------

%--------------------------------------------------------------------------
function pushbuttonNUM_Callback(hObject, eventdata, handles)




%--------------------------------------------------------------------------
function pushbuttonDelete_Callback(hObject, eventdata, handles)

    
%-------------------------------------------------------------------------

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
%-------------------------------------------------------------------------


%--------------------------------------------------------------------------
function PushButtonClear_Callback(hObject, eventdata, handles)


%-------------------------------------------------------------------------


% --------------------------------------------------------------------
function Bayes_Callback(hObject, eventdata, handles)
%-------------------------------------------------------------------------

% --------------------------------------------------------------------
function BayesTwoValue_Callback(hObject, eventdata, handles)

%global data
I=imread('��ǰ��д����.bmp');
data=GetFeature(I);
Result=BayesTwoValue(data);
Result=num2str(Result);
set(handles.TextResult,'String',Result);
%-------------------------------------------------------------------------

% --------------------------------------------------------------------
function BayesLeastError_Callback(hObject, eventdata, handles)

%global data
I=imread('��ǰ��д����.bmp');
data=GetFeature(I);
data=data';
Result=BayesLeastError(data);
Result=num2str(Result);
set(handles.TextResult,'String',Result);
%-------------------------------------------------------------------------


% --------------------------------------------------------------------
function BayesLeastRisk_Callback(hObject, eventdata, handles)

%global data
I=imread('��ǰ��д����.bmp');
data=GetFeature(I);
data=data';
Result=BayesLeastRisk(data);
Result=num2str(Result);
set(handles.TextResult,'String',Result);
%-------------------------------------------------------------------------



% --------------------------------------------------------------------
function Fisher_Callback(hObject, eventdata, handles)
I=imread('��ǰ��д����.bmp');
data=GetFeature(I);
data=data';
Result=Fisher(data);
Result=num2str(Result);
set(handles.TextResult,'String',Result);

% --------------------------------------------------------------------


% --------------------------------------------------------------------
function LinearClassification_Callback(hObject, eventdata, handles)
% --------------------------------------------------------------------



% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
global flag
global pos0  %
global x0 y0

pos0=get(handles.WritingAxes,'currentpoint');
x0=pos0(1,1);
y0=pos0(1,2);
if (pos0(1,1)>=0&pos0(1,1)<=100) && (pos0(1,2)>=0&pos0(1,2)<=100)  
    flag=1;
end
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
